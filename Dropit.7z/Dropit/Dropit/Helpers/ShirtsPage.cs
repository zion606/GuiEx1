﻿using Dropit.StepDefinitions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dropit.Helpers
{
    internal class ShirtsPage
    {
        string shopAppPageList = "shop-app[page='list']";
        string shopListNameList = "shop-list[name='list']";        
        string shopImage = "shop-image";
        internal IWebElement GetElement(string locator)
        {
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageList)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(shopListNameList)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow2 = shadow1.FindElement(By.CssSelector(locator)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow3 = shadow2.FindElement(By.CssSelector(shopImage)).GetShadowRoot();
            Thread.Sleep(1000);                       
            IWebElement element = shadow3.FindElement(By.CssSelector("#img"));
            return element;

        }
            
    }
}
