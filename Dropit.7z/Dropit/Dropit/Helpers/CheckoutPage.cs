﻿using Dropit.StepDefinitions;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dropit.Helpers
{
    internal class CheckoutPage
    {
        string shopAppPageCheckout = "shop-app[page='checkout']";
        string shopCheckoutNameCheckout = "shop-checkout[name='checkout']";

        internal void VerifyPageOpened()
        {            
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageCheckout)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(shopCheckoutNameCheckout)).GetShadowRoot();
            Thread.Sleep(1000);
            if (!shadow1.FindElement(By.CssSelector("span")).Displayed)
            {
                Assert.Fail("Failed to open checkout page");
            }
        }
        internal IWebElement GetElement(string locator)
        {
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageCheckout)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(shopCheckoutNameCheckout)).GetShadowRoot();
            Thread.Sleep(1000);
            return shadow1.FindElement(By.CssSelector(locator));
        }

        internal IWebElement GetErrorMessage(string errMsg)
        {            
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageCheckout)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(shopCheckoutNameCheckout)).GetShadowRoot();
            Thread.Sleep(1000);
            return shadow1.FindElement(By.CssSelector($"shop-md-decorator[error-message='{errMsg}']"));
        }

        internal void AddState(string state)
        {
            IWebElement element = GetElement("#shipState");
            element.SendKeys(state);
        }

        internal void AddCardHolderName(string cardHolderName)
        {
            IWebElement element = GetElement("#ccName");
            element.SendKeys(cardHolderName);
        }

        internal void AddCardNumber(string cardNumber)
        {
            IWebElement element = GetElement("#ccNumber");
            element.SendKeys(cardNumber);
        }

        internal void ClickFinish()
        {
            IWebElement element = GetElement("a[href='/']");
            element.Click();
        }

        internal void AddCvv(string cvv)
        {
            IWebElement element = GetElement("#ccCVV");
            element.SendKeys(cvv);
        }

        internal void ClickAtButton(string button)
        {
            IWebElement element = GetElement($"input[value='{button}']");
            element.Click();
        }

        internal void AddZipCode(string zipCode)
        {
            IWebElement element = GetElement("#shipZip");
            element.SendKeys(zipCode);
        }

        internal void AddCity(string city)
        {
            IWebElement element = GetElement("#shipCity");
            element.SendKeys(city);
        }

        internal void AddAddress(string address)
        {
            IWebElement element = GetElement("#shipAddress");
            element.SendKeys(address);
        }

        internal void AddPhoneNumber(string phoneNumber)
        {
            IWebElement element = GetElement("#accountPhone");
            element.SendKeys(phoneNumber);
        }

        internal void AddEmail(string email)
        {
            IWebElement element = GetElement("#accountEmail");
            element.SendKeys(email);
        }
    }
}
