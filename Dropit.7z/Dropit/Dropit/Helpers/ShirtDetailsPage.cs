﻿using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dropit.StepDefinitions;

namespace Dropit.Helpers
{
    internal class ShirtDetailsPage
    {
        string shopAppPageDetail = "shop-app[page='detail']";
        string shopDetailNameDetail = "shop-detail[name='detail']";
        string sizeCssSelector = "#sizeSelect";
        string quantityCssSelector = "#quantitySelect";
        string classOpened = ".opened";

        internal void SelectQuantity(string expectedQuantity)
        {

            ISearchContext shadow1 = GetShopDetail();
            IWebElement quantityElement = shadow1.FindElement(By.CssSelector(quantityCssSelector));
            SelectValue(quantityElement, expectedQuantity);
        }

        internal void SelectSize(string expectedSize)
        {
            ISearchContext shadow1 = GetShopDetail();
            IWebElement sizeElement = shadow1.FindElement(By.CssSelector(sizeCssSelector));
            SelectValue(sizeElement, expectedSize);
        }

        internal void ViewCart()
        {                        
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageDetail)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(classOpened)).GetShadowRoot();
            Thread.Sleep(1000);
            shadow1.FindElement(By.CssSelector("#viewCartAnchor")).Click();
        }

        private ISearchContext GetShopDetail()
        {
            
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageDetail)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(shopDetailNameDetail)).GetShadowRoot();
            Thread.Sleep(1000);
            return shadow1;
        }

        private void SelectValue(IWebElement comboElement, string expectedValue)
        {
            SelectElement select = new SelectElement(comboElement);
            IList<IWebElement> options = select.Options;
            List<string> actualValues = new List<string>();
            foreach (IWebElement currentValue in options)
            {
                actualValues.Add(currentValue.GetAttribute("value"));
            }

            IWebElement selectedOption = select.SelectedOption;
            string selectedValue = selectedOption.GetAttribute("value");

            int currentIndex = actualValues.IndexOf(selectedValue);
            int wantedIndex = actualValues.IndexOf(expectedValue);
            int numOfClicks = wantedIndex - currentIndex;
            string key = string.Empty;
            if (numOfClicks > 0)
            {
                key = Keys.ArrowDown;
            }
            else if (numOfClicks < 0)
            {
                key = Keys.ArrowUp;
            }

            for (int i = 0; i < Math.Abs(numOfClicks); i++)
            {
                comboElement.SendKeys(key);
            }
            comboElement.SendKeys(Keys.Enter);
            comboElement.Click();
        }
    }
}
