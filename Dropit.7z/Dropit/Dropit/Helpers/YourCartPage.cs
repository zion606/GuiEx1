﻿using Dropit.StepDefinitions;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Dropit.Helpers
{
    internal class YourCartPage
    {
        string cssSelectorForHost1 = "shop-app[page='detail']";
        string cssSelectorForHost2 = "paper-icon-button[aria-label^='Shopping cart']";
        string shopAppPageCart = "shop-app[page='cart']";
        string shopCartNameCart = "shop-cart[name='cart']";
        string totalCssSelector = ".subtotal";

        internal void Checkout()
        {            
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageCart)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(shopCartNameCart)).GetShadowRoot();
            Thread.Sleep(1000);
            shadow1.FindElement(By.CssSelector("a[href='/checkout']")).Click();
            CheckoutPage checkout = new CheckoutPage();
            checkout.VerifyPageOpened();
        }

        internal IWebElement GetCart(string name)
        {
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(cssSelectorForHost1)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(cssSelectorForHost2)).GetShadowRoot();
            Thread.Sleep(1000);
            return shadow1.FindElement(By.CssSelector($"#{name}"));
        }

        internal string GetTotal()
        {
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageCart)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(shopCartNameCart)).GetShadowRoot();
            Thread.Sleep(1000);
            return shadow1.FindElement(By.CssSelector(totalCssSelector)).Text;
        }

        internal string GetTotalParts()
        {
            Thread.Sleep(1000);
            ISearchContext shadow0 = ShopDefinitions._driver.FindElement(By.CssSelector(shopAppPageCart)).GetShadowRoot();
            Thread.Sleep(1000);
            IWebElement element = shadow0.FindElement(By.CssSelector(cssSelectorForHost2));
            Thread.Sleep(1000);
            string ariaLabel = element.GetAttribute("aria-label");
            ariaLabel = ariaLabel.Replace("Shopping cart: ", "").Replace(" items", "");
            return ariaLabel;
        }
    }
}
