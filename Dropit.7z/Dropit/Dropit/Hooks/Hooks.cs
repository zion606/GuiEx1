﻿using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dropit.StepDefinitions;
using TechTalk.SpecFlow.Infrastructure;

namespace Dropit.Hooks
{
    internal class Hooks
    {

        [BeforeScenario]
        public void BeforeScenario()
        {
            
        }

        [AfterScenario]
        public void AfterScenario()
        {
            if (ShopDefinitions._driver != null)
            {
                ShopDefinitions._driver.Quit();
                ShopDefinitions._driver = null;
            }
        }

    }
}
