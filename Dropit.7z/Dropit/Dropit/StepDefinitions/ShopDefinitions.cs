using Dropit.Features;
using Dropit.Helpers;
using Microsoft.Extensions.DependencyModel;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.DevTools.V123.DOM;
using OpenQA.Selenium.DevTools.V123.Network;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System.Runtime.Serialization;
using System.Xml.Linq;

namespace Dropit.StepDefinitions
{
    [Binding]
    public sealed class ShopDefinitions
    {
        public static IWebDriver _driver = null;
        public static WebDriverWait wait;
        CheckoutPage checkout;
        ShirtsPage shirts;
        YourCartPage yourCart;
        ShirtDetailsPage shirtDetailsPage;
        ShopDefinitions()
        {            
            checkout = new CheckoutPage();
            shirts = new ShirtsPage();
            yourCart = new YourCartPage();
            shirtDetailsPage = new ShirtDetailsPage();
            ChromeDriverService service = ChromeDriverService.CreateDefaultService();
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("no-sandbox");            
            options.AddArgument("start-maximized");            
            _driver = new ChromeDriver(service, options);
            _driver.Manage().Window.Maximize();
            wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
        }


        [Given(@"I browse to shop home page")]
        public void GivenIBrowseToShopPage()
        {
            _driver.Navigate().GoToUrl("https://shop.polymer-project.org/");
            Thread.Sleep(3000);
        }


        [When(@"I click on tab ""([^""]*)""")]
        public void WhenIClickOn(string elementName)
        {
            elementName = elementName.Replace(" ", "_").Replace("'", "").Replace("-","").ToLower();
            string cssSelectorForHost1 = "shop-app[page='home']";
            Thread.Sleep(1000);
            ISearchContext shadow = _driver.FindElement(By.CssSelector(cssSelectorForHost1)).GetShadowRoot();
            Thread.Sleep(1000);
            IWebElement element = shadow.FindElement(By.CssSelector($"a[href='/list/{elementName}']"));
            element.Click();
        }

        [When(@"I click on shirt ""([^""]*)""")]
        public void WhenIClickOnShirt(string shirtName)
        {                     
            string locator = " ul:nth-child(6) > li:nth-child(5) > a:nth-child(1) > shop-list-item:nth-child(1)";            
            IWebElement element = shirts.GetElement(locator);
            element.Click();
        }

        [When(@"I click on ladies shirt ""([^""]*)""")]
        public void WhenIClickOnLadiesShirt(string shirtName)
        {
            string locator = " ul:nth-child(6) > li:nth-child(18) > a:nth-child(1) > shop-list-item:nth-child(1)";
            IWebElement element = shirts.GetElement(locator);
            element.Click();
        }

        [When(@"I select size ""([^""]*)""")]
        public void WhenISelectSize(string expectedSize)
        {                                    
            shirtDetailsPage.SelectSize(expectedSize);
        }
        
        [When(@"I select quantity ""([^""]*)""")]
        public void WhenISelectQuantity(string expectedQuantity)
        {
            shirtDetailsPage.SelectQuantity(expectedQuantity);
        }

        [When(@"I add to cart")]
        public void WhenIAddToCart()
        {
            string cssSelectorForHost1 = "shop-app[page='detail']";
            string cssSelectorForHost2 = "shop-detail[name='detail']";
            Thread.Sleep(1000);
            ISearchContext shadow0 = _driver.FindElement(By.CssSelector(cssSelectorForHost1)).GetShadowRoot();
            Thread.Sleep(1000);
            ISearchContext shadow1 = shadow0.FindElement(By.CssSelector(cssSelectorForHost2)).GetShadowRoot();
            Thread.Sleep(1000);
            shadow1.FindElement(By.CssSelector("button[aria-label='Add this item to cart']")).Click();         
        }

        [When(@"I view cart")]
        public void WhenIViewCart()
        {
            shirtDetailsPage.ViewCart();
        }

        [When(@"I click on the cart ""([^""]*)""")]
        public void WhenIClickOnTheCart(string name)
        {
            IWebElement cartButton =  yourCart.GetCart(name);
            cartButton.Click();            
        }

        [When(@"I verify total parts is ""([^""]*)""")]
        public void WhenIVerifyTotalPartsIs(string expectedTotal)
        {            
            string actualTotal = yourCart.GetTotalParts();
            if (!actualTotal.Equals(expectedTotal))
            {
                Assert.Fail($"Expected total parts is: [{expectedTotal}] while actual total is: [{actualTotal}]");
            }
        }


        [When(@"I verify total money to pay is ""([^""]*)""")]
        public void WhenIVerifyTotalMoneyToPayIs(string expectedTotal)
        {         
            string actualTotal = yourCart.GetTotal().Replace("$", "");
            if (!actualTotal.Equals(expectedTotal))
            {
                Assert.Fail($"Expected total money is: [{expectedTotal}] while actual total is: [{actualTotal}]");
            }            
        }


        [When(@"I checkout")]
        public void WhenICheckout()
        {
            yourCart.Checkout();            
        }

        [When(@"fill email ""([^""]*)""")]
        public void WhenFillEmail(string email)
        {
            checkout.AddEmail(email);            
        }

        [When(@"I add phone number ""([^""]*)""")]
        public void WhenIAddPhoneNumber(string phoneNumber)
        {
            checkout.AddPhoneNumber(phoneNumber);            
        }

        [When(@"I add Address ""([^""]*)""")]
        public void WhenIAddAddress(string address)
        {           
            checkout.AddAddress(address);            
        }

        [When(@"I add City ""([^""]*)""")]
        public void WhenIAddCity(string city)
        {
            checkout.AddCity(city);            
        }

        [When(@"I add zip code ""([^""]*)""")]
        public void WhenIAddZipCode(string zipCode)
        {
            checkout.AddZipCode(zipCode);            
        }

        [When(@"I add State ""([^""]*)""")]
        public void WhenIAddState(string state)
        {
            checkout.AddState(state);            
        }

        [When(@"I add CardHolder name ""([^""]*)""")]
        public void WhenIAddCardHolderName(string cardHolderName)
        {
            checkout.AddCardHolderName(cardHolderName);            
        }

        [When(@"I add Card number""([^""]*)""")]
        public void WhenIAddCardNumber(string cardNumber)
        {
            checkout.AddCardNumber(cardNumber);            
        }

        [Then(@"I click at finish")]
        public void WhenIClickAtFinish()
        {
            checkout.ClickFinish();            
        }

        [When(@"I add CVV ""([^""]*)""")]
        public void WhenIAddCVV(string cvv)
        {
            checkout.AddCvv(cvv);            
        }

        [When(@"I click at ""([^""]*)""")]
        public void WhenIClickAt(string button)
        {
            checkout.ClickAtButton(button);            
        }

        [Then(@"""([^""]*)"" red message is shown")]
        public void ThenRedMessageIsShown(string errMsg)
        {
            IWebElement errElement = checkout.GetErrorMessage(errMsg);
            if (!errElement.Displayed)
            {
                Assert.Fail($"err msg {errMsg} expected but it not shown");
            }
                
        }


    }
}


